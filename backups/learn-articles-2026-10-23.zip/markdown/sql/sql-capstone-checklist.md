---
slug: sql-capstone-checklist
title: Capstone SQL — чеклист Junior→Senior и индекс Q→slug
shortTitle: Чеклист SQL
episode: SQL16
rubric: data
order: 616
publishedAt: 2027-05-01T10:00:00+03:00
profiles: [developer, analyst, tester]
level: senior
tags: [sql, capstone, checklist, индекс, собеседование]
onKnowledgeMap: true
durationMin: 35
excerpt: Итоговый чеклист SQL Junior→Senior, индекс Q1–Q30→slug, ссылка на Хабр Часть I; Часть II исходных 65 не найдена — расширения в SQL13–14.
prerequisites: [sql-interview-drill]
seoTitle: Capstone SQL чеклист Junior Senior и индекс вопросов
seoDescription: SQL16: чеклисты уровней, полный индекс Q→выпуск Learn, маршрут повторения и примечание о пропавшей Части II OTUS/Хабр.
seoKeywords: [SQL, checklist, capstone, собеседование, PostgreSQL, индекс]
canonicalUrl: https://9to18.ru/game/learn/sql-capstone-checklist
---

## Введение

Финальный выпуск серии SQL Learn: собрать траекторию Junior → Middle → Senior, пройти self-check и быстро найти выпуск по номеру вопроса Qi. Полные формулировки Q1–Q30 — в [Части I на Хабре](https://habr.com/ru/companies/otus/articles/461067/); здесь — **ориентиры компетенций** и навигация. Часть II исходного «топ-65» на Хабре **не найдена**; темы вроде CTE, окон и EXPLAIN закрыты выпусками SQL13–SQL14.

## Раздел: Ответ вслух

Перед собесом я проверяю три вещи вслух: чем DELETE отличается от TRUNCATE, когда нужен внешний ключ, и что EXPLAIN может показать последовательное чтение даже при живом индексе.

## Раздел: Плохой ответ

Закрыть чеклист галочками, не произнеся ни одного ответа. Галочка не слышна интервьюеру.

## Раздел: Термины

Целостность — integrity. План — execution plan. Внешний ключ — foreign key.

## Раздел: Чеклисты Junior → Middle → Senior

**Как пользоваться серией.**

1. Идите по `order` 601→616 или точечно по индексу Q→slug ниже.
2. Выпуск: теория → лаба → тест → Anki; SQL12 не пропускайте.
3. Держите открытой [Часть I OTUS/Хабр](https://habr.com/ru/companies/otus/articles/461067/) для формулировок; ответы готовьте свои (PostgreSQL-first).
4. После Middle-лабы обязательны SQL13–14, даже если их не было в Q1–Q30.
5. SQL15 — таймер; SQL16 — чеклист перед собесом.

**Чеклист Junior (SQL01–SQL06).**

- [ ] DDL / DML / DCL и «SQL ≠ СУБД»
- [ ] PK / UK / FK, constraints, целостность
- [ ] DELETE vs TRUNCATE vs DROP
- [ ] INNER/LEFT/RIGHT/FULL/CROSS; идея NATURAL
- [ ] CHAR/VARCHAR/text, трёхзначная логика NULL
- [ ] Зачем индекс; clustered vs secondary с оговоркой диалекта

**Чеклист Middle (SQL07–SQL12).**

- [ ] 1–3НФ, сущность, когда денормализуют
- [ ] ACID и границы транзакции
- [ ] Триггеры BEFORE/AFTER, NEW/OLD; операторы и NULL
- [ ] Подзапросы; correlated vs not; NOT EXISTS
- [ ] CURRENT_DATE/now vs GETDATE; COUNT(*) vs COUNT(col) vs estimate
- [ ] Сводная лаба: JOIN, anti-join, агрегаты, удаление на одной схеме

**Чеклист Senior (SQL13–SQL15 + практика).**

- [ ] CTE (WITH), при необходимости рекурсия; отличие от TEMP
- [ ] ROW_NUMBER / RANK / SUM OVER; «последняя строка в группе»
- [ ] EXPLAIN vs EXPLAIN ANALYZE; Seq vs Index Scan
- [ ] Когда индекс помогает/вредит; идея covering; N+1
- [ ] Drill Q1–Q30 за ≤90 с с примером
- [ ] Честно разделяете PostgreSQL / MSSQL / MySQL в ответах

## Раздел: Индекс Q1–Q30 → slug

| Q | Тема (кратко) | slug |
|---|----------------|------|
| Q1 | DELETE vs TRUNCATE | `sql-delete-truncate-drop` |
| Q2 | DDL/DML/DCL | `sql-ddl-dml-dcl` |
| Q3 | SQL vs MySQL | `sql-ddl-dml-dcl` |
| Q4 | Таблица / поле | `sql-tables-keys-constraints` |
| Q5 | JOIN | `sql-joins` |
| Q6 | CHAR vs VARCHAR | `sql-types-null` |
| Q7 | Primary key | `sql-tables-keys-constraints` |
| Q8 | Constraints / связанные | `sql-tables-keys-constraints` |
| Q9 | Зачем СУБД | `sql-ddl-dml-dcl` |
| Q10 | Constraints | `sql-tables-keys-constraints` |
| Q11 | Unique vs PK | `sql-tables-keys-constraints` |
| Q12 | Целостность | `sql-tables-keys-constraints` |
| Q13 | Индекс | `sql-indexes-basics` |
| Q14 | Текущая дата | `sql-agg-dates-count` |
| Q15 | Виды JOIN | `sql-joins` |
| Q16 | Нормализация | `sql-normalization` |
| Q17 | 1–3 НФ | `sql-normalization` |
| Q18 | Clustered index | `sql-indexes-basics` |
| Q19 | Nonclustered | `sql-indexes-basics` |
| Q20 | Денормализация | `sql-normalization` |
| Q21 | DROP | `sql-delete-truncate-drop` |
| Q22 | Сущность | `sql-normalization` |
| Q23 | ACID | `sql-acid-transactions` |
| Q24 | Триггер | `sql-triggers-operators` |
| Q25 | Операторы | `sql-triggers-operators` |
| Q26 | NULL | `sql-types-null` |
| Q27 | CROSS vs NATURAL | `sql-joins` |
| Q28 | Подзапрос | `sql-subqueries` |
| Q29 | Correlated | `sql-subqueries` |
| Q30 | COUNT | `sql-agg-dates-count` |

**Расширения сверх Части I (вместо отсутствующей Части II).**

| Тема | slug |
|------|------|
| Практика сводная | `sql-practice-lab` |
| CTE + window | `sql-cte-window` |
| EXPLAIN, индексы на практике, N+1 | `sql-performance-explain` |
| Устный drill | `sql-interview-drill` |
| Capstone / этот индекс | `sql-capstone-checklist` |

**Обзор серии SQL Learn.**

| Ep | slug | Фокус |
|----|------|--------|
| SQL01 | sql-ddl-dml-dcl | Подмножества, СУБД |
| SQL02 | sql-tables-keys-constraints | Ключи, constraints |
| SQL03 | sql-delete-truncate-drop | DELETE/TRUNCATE/DROP |
| SQL04 | sql-joins | JOIN |
| SQL05 | sql-types-null | Типы, NULL |
| SQL06 | sql-indexes-basics | Индексы |
| SQL07 | sql-normalization | НФ |
| SQL08 | sql-acid-transactions | ACID |
| SQL09 | sql-triggers-operators | Триггеры, операторы |
| SQL10 | sql-subqueries | Подзапросы |
| SQL11 | sql-agg-dates-count | Дата, COUNT |
| SQL12 | sql-practice-lab | Сводная лаба |
| SQL13 | sql-cte-window | CTE, окна |
| SQL14 | sql-performance-explain | Планы, perf |
| SQL15 | sql-interview-drill | Drill Q1–30 |
| SQL16 | sql-capstone-checklist | Capstone |

## Раздел: План на 2 недели до собеса

**Неделя 1.** Закрыть ❌ в Junior+Middle чеклистах; один раз полностью прогнать SQL12 на чистой БД; Anki по слабым Qi.  
**Неделя 2.** SQL13–14 с `EXPLAIN ANALYZE` на своих данных; ежедневный drill SQL15 (по 10 случайных Qi); пробный live-coding: «клиенты без заказов», «последний заказ», «сумма paid за сегодня».

Артефакт «папка доказательств»: скрипт схемы магазина, 10 SQL-решений, 2 скрина/текста планов до/после индекса, список ловушек NULL/диалектов своими словами.

## Раздел: Частые вопросы с собеседования
**Вопрос.** План на 2 недели — приоритет?

**Ответ.** Сначала пробелы ❌ из drill по индексу slug, каждый день 1 тема + 2 SQL руками + один EXPLAIN. Повтор ✅ через неделю устно, без подсказок.

**Вопрос.** Senior SQL без ORM — что показать?

**Ответ.** Транзакции, isolation choice, индексы под реальные запросы, миграции без downtime (expand/contract), observability slow query log. Чеклист SQL16 — self-assessment.

**Вопрос.** Q1–Q30 индекс — как не перепутать с otus-статьёй?

**Ответ.** Индекс — маршрут к вашим выпускам с оригинальными формулировками; не копируйте чужие ответы дословно. На собесе важны примеры из вашего опыта.

**Вопрос.** Когда STOP учить новое SQL перед собесом?

**Ответ.** За 2–3 дня — только повтор слабых и sleep. Новые window-функции в ночь перед — хуже, чем уверенный JOIN/NULL/ACID.

## Лаба

**Цель.** Заполнить чеклисты и собрать персональный индекс пробелов Qi → действия.

**Шаги.**
1. Пройдите три чеклиста выше маркерами ✅/❌.
2. Для каждого ❌ выпишите slug и одну лабу/Anki на повторение.
3. Сверьте, что Q24–Q25, Q28–Q29, Q14/Q30 реально закрыты SQL09–11 (не только «читал Хабр»).
4. Отметьте отдельно статус SQL13–14 — даже если в Части I их не было.
5. Назначьте дату повторного drill SQL15.

**В группу:** обменяйтесь списками ❌ и проведите взаимный мини-собес на 15 минут.

**Готово, если…**
- [ ] Junior и Middle чеклисты ≥80% ✅
- [ ] SQL13–14 осознанно пройдены или запланированы
- [ ] Есть персональная таблица Qi → slug → статус

## Схема: Траектория серии

```mermaid
flowchart LR
  J[SQL01-06 Junior] --> M[SQL07-12 Middle]
  M --> S[SQL13-14 Senior extra]
  S --> D[SQL15 Drill]
  D --> C[SQL16 Capstone]
  H[Habr Part I Q1-30] -.-> M
  X[Part II не найдена] -.-> S
```

## Тест

### Чем DELETE отличается от TRUNCATE по откату?

**Ответ:** DELETE в транзакции откатывается

**Пояснение:** TRUNCATE в PostgreSQL тоже транзакционен, но это DDL-подобная операция с другими блокировками и сбросом identity — на собесе уточняйте диалект.

### Зачем CTE и window на middle/senior SQL?

**Ответ:** читаемые сложные выборки

**Пояснение:** WITH и OVER закрывают ранги, нарастающие итоги и многошаговую логику без временных таблиц.

### Что считать критерием «готов к middle SQL-собесу»?

**Ответ:** JOIN ACID индексы подзапросы

**Пояснение:** плюс руки на лабе и устойчивые ответы на типовые ловушки NULL/COUNT.

### Где безопасно тренировать JOIN и агрегаты?

**Ответ:** PG Exercises, Select Star

**Пояснение:** интерактивные задачи; документация PostgreSQL — эталон поведения.

### Что показывает EXPLAIN про индекс?

**Ответ:** Seq Scan или Index Scan

**Пояснение:** смотрите узлы плана и оценки строк — индекс «есть» ≠ «используется».

## Шпаргалка

<h3>Уровни</h3>
<ul>
<li>Junior: DDL/DML, ключи, JOIN, NULL, индекс, DELETE/TRUNCATE</li>
<li>Middle: НФ, ACID, триггеры, подзапросы, COUNT/даты, сводная лаба</li>
<li>Senior: CTE, window, EXPLAIN, N+1, темп drill</li>
</ul>
<h3>Источник</h3>
<ul>
<li>Формулировки Q1–30: Хабр OTUS Часть I</li>
<li>Часть II: не найдена → SQL13–14</li>
</ul>
<pre><code>Qi → таблица индекса → slug выпуска</code></pre>

## Anki

### Front: Где в серии триггеры и операторы?

Back: sql-triggers-operators (SQL09, Q24–Q25)

### Front: Что делать с отсутствующей Частью II топ-65?

Back: Опираться на SQL13–14 (CTE/window/EXPLAIN) как на обязательное расширение

### Front: Минимум перед SQL middle-собесом?

Back: SQL01–12 чеклист + руки на схеме customers/orders + drill слабых Qi

### Front: SQL14 про что?

Back: EXPLAIN, индексы на практике, N+1

### Front: profiles серии SQL?

Back: developer, analyst, tester — все 16 выпусков

### Front: order SQL16?

Back: 616 — capstone и индекс Q→slug

## Итоги

- Capstone = чеклисты + индекс Q→slug + честный план повторения
- Хабр Часть I — формулировки; Learn — ваши разборы под PostgreSQL
- Часть II не найдена: senior-темы закрыты SQL13–14, не оставляйте их «на потом»

## Ссылки

- [PostgreSQL: Documentation](https://www.postgresql.org/docs/current/)
- [Use The Index, Luke!](https://use-the-index-luke.com/)
- [Select Star SQL](https://selectstarsql.com/) · [PG Exercises](https://pgexercises.com/)
- Индекс Q1–Q30: [OTUS / Хабр — часть I](https://habr.com/ru/companies/otus/articles/461067/)
- Начало серии: [DDL DML DCL](/game/learn/sql-ddl-dml-dcl)
